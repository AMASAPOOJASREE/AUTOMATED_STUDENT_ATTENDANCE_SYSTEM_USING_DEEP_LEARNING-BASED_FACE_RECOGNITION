from django.contrib import admin
from django.urls import path
from FACE_RECOGNITION_BASED_ATTENDANCE_MANAGEMENT_SYSTEM_USING_DEEP_LEARNING import views as mv
from Students import views as sv
from Faculty import views as fv
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    # ======================
    # ADMIN
    # ======================
    path('admin/', admin.site.urls),

    # ======================
    # COMMON / HOME
    # ======================
    path('', mv.index, name='index'),

    # ======================
    # STUDENT
    # ======================
    path('studentRegister/', mv.studentRegister, name='studentRegister'),
    path('studentLogin/', mv.studentLogin, name='studentLogin'),
    path('student_register/', sv.student_register, name='student_register'),

    # Live camera
    path('live_stream/', sv.realtime, name='live_stream'),

    # Automatic attendance
    path('auto_attendance/', sv.auto_attendance, name='auto_attendance'),
    path('validate_face/', sv.auto_attendance, name='validate_face'),

    # ======================
    # FACULTY
    # ======================
    path('facultyLogin/', mv.facultyLogin, name='facultyLogin'),
    path('facultyLoginCheck/', fv.facultyLoginCheck, name='facultyLoginCheck'),
    path('facultyHome/', fv.facultyHome, name='facultyHome'),

    path('studentAttendance/', fv.studentAttendance, name='studentAttendance'),
    path('dayWiseReports/', fv.dayWiseReports, name='dayWiseReports'),
    path(
        'download_daywise_csv/<str:date>/',
        fv.download_daywise_csv,
        name='download_daywise_csv'
    ),

    # 🔥 Analytics Dashboard
    path('analytics/', fv.analyticsDashboard, name='analytics'),

    # Logout
    path('log/', fv.log, name='log'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
