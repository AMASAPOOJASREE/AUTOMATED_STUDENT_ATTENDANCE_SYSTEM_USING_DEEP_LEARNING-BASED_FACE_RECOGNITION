from django.shortcuts import render
from django.contrib import messages
from django.http import Http404, HttpResponse
from django.utils.timezone import localtime
from django.db.models import Count
import csv

from Students.models import Attendance


# =========================
# FACULTY LOGIN
# =========================
def facultyLoginCheck(request):
    if request.method == 'POST':
        loginid = request.POST.get('loginid')
        password = request.POST.get('password')

        if loginid == "admin" and password == "admin":
            request.session['admin'] = True
            return render(request, 'faculty/facultyHome.html')
        else:
            messages.error(request, 'Invalid details, please try again')
            return render(request, 'facultyLogin.html')

    return render(request, 'facultyLogin.html')


# =========================
# FACULTY HOME
# =========================
def facultyHome(request):
    if not request.session.get('admin'):
        return render(request, 'facultyLogin.html')
    return render(request, 'faculty/facultyHome.html')


# =========================
# LOGOUT
# =========================
def log(request):
    request.session.flush()
    return render(request, 'facultyLogin.html')


# =========================
# STUDENT ATTENDANCE VIEW
# =========================
def studentAttendance(request):
    if not request.session.get('admin'):
        return render(request, 'facultyLogin.html')

    records = Attendance.objects.order_by('date', 'period', 'student_id')

    for rec in records:
        rec.local_time = localtime(rec.timestamp)

    return render(request, 'faculty/attendance.html', {
        'records': records,
        'title': 'Day-wise Hourly Attendance'
    })


# =========================
# DAY-WISE REPORT PAGE
# =========================
def dayWiseReports(request):
    if not request.session.get('admin'):
        return render(request, 'facultyLogin.html')

    context = {}

    if request.method == "POST":
        selected_date = request.POST.get("date")

        if Attendance.objects.filter(date=selected_date).exists():
            context["file_exists"] = True
            context["selected_date"] = selected_date
        else:
            context["file_exists"] = False
            context["error"] = "No attendance found for selected date"

    return render(request, 'faculty/daywisereport.html', context)


# =========================
# DOWNLOAD DAY-WISE CSV
# =========================
def download_daywise_csv(request, date):
    if not request.session.get('admin'):
        return render(request, 'facultyLogin.html')

    records = Attendance.objects.filter(date=date).order_by(
        'student_id', 'period'
    )

    if not records.exists():
        raise Http404("No attendance found for selected date")

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = (
        f'attachment; filename="attendance_{date}.csv"'
    )

    writer = csv.writer(response)
    writer.writerow(["Student ID", "Date", "Period", "Status", "Time (IST)"])

    for rec in records:
        local_ts = localtime(rec.timestamp)
        writer.writerow([
            rec.student_id,
            rec.date,
            rec.period,
            rec.classification,
            local_ts.strftime("%I:%M %p")
        ])

    return response


# =========================
# 🔥 ANALYTICS DASHBOARD
# =========================
def analyticsDashboard(request):
    if not request.session.get('admin'):
        return render(request, 'facultyLogin.html')

    # Total working days
    total_days = Attendance.objects.values('date').distinct().count()

    # Student-wise present count
    student_stats = (
        Attendance.objects
        .filter(classification='Present')
        .values('student_id')
        .annotate(present_count=Count('id'))
        .order_by('student_id')
    )

    # Day-wise attendance count
    day_wise = (
        Attendance.objects
        .values('date')
        .annotate(total=Count('id'))
        .order_by('date')
    )

    # Period-wise attendance
    period_wise = (
        Attendance.objects
        .values('period')
        .annotate(total=Count('id'))
        .order_by('period')
    )

    context = {
        'total_days': total_days,
        'student_stats': student_stats,
        'day_wise': day_wise,
        'period_wise': period_wise,
    }

    return render(request, 'faculty/analytics.html', context)

